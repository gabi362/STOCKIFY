document.querySelectorAll('nav a').forEach(a=>{if(a.getAttribute('href')===location.pathname.split('/').pop()||(a.getAttribute('href')==='index.html'&&!location.pathname.split('/').pop()))a.classList.add('on')});
const f=document.getElementById('f');
if(f)f.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(f),b=encodeURIComponent('Nombre: '+d.get('n')+'\nTipo de web: '+d.get('t')+'\n\n'+d.get('m'));location.href='mailto:hola@tecreamoswebs.com?subject='+encodeURIComponent('Quiero una web: '+d.get('t'))+'&body='+b});
