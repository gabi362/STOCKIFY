# Te creamos webs
Web estática (HTML, CSS y JS). No necesita instalación.

## Publicar en GitHub Pages
1. Sube todos estos archivos a la raíz del repositorio (index.html debe estar en la raíz).
2. Settings > Pages > Source: "Deploy from a branch" > Branch: main, carpeta /(root) > Save.
3. En 1-2 minutos estará en https://TU-USUARIO.github.io/NOMBRE-REPO/
